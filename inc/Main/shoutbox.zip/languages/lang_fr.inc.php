<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Nom";
  $msg['eMail']     = "eMail";
  $msg['message']   = "Message";
  $msg['smilies']   = "Emoticônes";
  $msg['refresh']   = "Vider";
  $msg['shout']     = "Envoyer!";
  $msg['delete']    = "Supprimer";
  $msg['confirm']   = "Supprimer définitivement?";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Saisissez le mot de passe:";
  $msg['wrongPass'] = "Mauvais mot de passe!";
  $msg['noSpam']    = "NO SPAM PLEASE!";
