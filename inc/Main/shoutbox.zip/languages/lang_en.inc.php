<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Name";
  $msg['eMail']     = "eMail";
  $msg['message']   = "Message";
  $msg['smilies']   = "Smilies";
  $msg['refresh']   = "Refresh";
  $msg['shout']     = "Shout!";
  $msg['delete']    = "Delete";
  $msg['confirm']   = "Delete irreversibly?";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Enter password:";
  $msg['wrongPass'] = "Wrong password!";
  $msg['noSpam']    = "NO SPAM PLEASE!";
