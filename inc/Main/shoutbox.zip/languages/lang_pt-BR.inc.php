<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Nome";
  $msg['eMail']     = "email";
  $msg['message']   = "Mensagem";
  $msg['smilies']   = "Caretas";
  $msg['refresh']   = "Atualizar";
  $msg['shout']     = "Enviar";
  $msg['delete']    = "Cancelar";
  $msg['confirm']   = "Realmente Cancelar";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Senha:";
  $msg['wrongPass'] = "Senha Incorreta";
  $msg['noSpam']    = "SEM SPAM, POR FAVOR!";
