<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Όνομα";
  $msg['eMail']     = "eMail";
  $msg['message']   = "Μήνυμα";
  $msg['smilies']   = "Smilies";
  $msg['refresh']   = "Ανανέωση";
  $msg['shout']     = "Shout!";
  $msg['delete']    = "Διαγραφή";
  $msg['confirm']   = "Μη αναστρέψιμη διαγραφή?";
  $msg['admin']     = "Διαχειριστής";
  $msg['pass']      = "Εισαγωγή κωδικού";
  $msg['wrongPass'] = "Λάθος κωδικός!";
  $msg['noSpam']    = "NO SPAM PLEASE!";
