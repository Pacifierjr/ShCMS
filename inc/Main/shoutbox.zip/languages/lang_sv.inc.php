<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Namn";
  $msg['eMail']     = "E-post";
  $msg['message']   = "Meddelande";
  $msg['smilies']   = "Flinis";
  $msg['refresh']   = "Uppdatera";
  $msg['shout']     = "Ropa!";
  $msg['delete']    = "Ta bort";
  $msg['confirm']   = "Radera för alltid?";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Ange lösenord:";
  $msg['wrongPass'] = "Fel lösenord!";
  $msg['noSpam']    = "NO SPAM PLEASE!";
