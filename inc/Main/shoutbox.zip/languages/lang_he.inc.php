<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "שם";
  $msg['eMail']     = "אימייל";
  $msg['message']   = "הודעה";
  $msg['smilies']   = "סמלים";
  $msg['refresh']   = "רענן";
  $msg['shout']     = "שלח";
  $msg['delete']    = "מחק";
  $msg['confirm']   = "למחוק לצמיתות?";
  $msg['admin']     = "מנהל";
  $msg['pass']      = "הכנס סיסמה:";
  $msg['wrongPass'] = "סיסמה שגויה!";
  $msg['noSpam']    = "בלי ספאם בבקשה!";
