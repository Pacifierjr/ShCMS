<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Nimi";
  $msg['eMail']     = "Sähköposti";
  $msg['message']   = "Viesti";
  $msg['smilies']   = "Smaili";
  $msg['refresh']   = "Päivittää";
  $msg['shout']     = "Huutaa!";
  $msg['delete']    = "Kumoa";
  $msg['confirm']   = "Kumoa koko ketju?";
  $msg['admin']     = "Valvooja";
  $msg['pass']      = "Anna salasana:";
  $msg['wrongPass'] = "Väärä salasana!";
  $msg['noSpam']    = "NO SPAM PLEASE!";
