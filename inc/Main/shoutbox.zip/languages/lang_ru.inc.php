<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Имя";
  $msg['eMail']     = "eMail";
  $msg['message']   = "Сообщение";
  $msg['smilies']   = "Смайлики";
  $msg['refresh']   = "Обновить";
  $msg['shout']     = "Отправить";
  $msg['delete']    = "Удалить";
  $msg['confirm']   = "Удалить безвозвратно?";
  $msg['admin']     = "Админ";
  $msg['pass']      = "Введите пароль:";
  $msg['wrongPass'] = "Неправильный пароль!";
  $msg['noSpam']    = "СПАМ ЗАПРЕЩЁН!";
