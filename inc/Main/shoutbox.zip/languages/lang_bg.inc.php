<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Име";
  $msg['eMail']     = "eMail";
  $msg['message']   = "Съобщение";
  $msg['smilies']   = "Емотикони";
  $msg['refresh']   = "Обнови";
  $msg['shout']     = "Давай!";
  $msg['delete']    = "Изтрий";
  $msg['confirm']   = "Изтриванe завинаги?";
  $msg['admin']     = "Админ";
  $msg['pass']      = "Въведи парола:";
  $msg['wrongPass'] = "Грешна парола!";
  $msg['noSpam']    = "БЕЗ СПАМ МОЛЯ!";
