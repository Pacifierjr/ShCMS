<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Imię";
  $msg['eMail']     = "Email";
  $msg['message']   = "Wiadomość";
  $msg['smilies']   = "Ikonki";
  $msg['refresh']   = "Odśwież";
  $msg['shout']     = "Wyślij!";
  $msg['delete']    = "Usuń";
  $msg['confirm']   = "Bezpowrotnie usunąć?";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Wpisz hasło:";
  $msg['wrongPass'] = "Złe hasło!";
  $msg['noSpam']    = "PROSZĘ NIE SPAMUJ!";
