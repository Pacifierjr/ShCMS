<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Nombre";
  $msg['eMail']     = "eMail";
  $msg['message']   = "Recado";
  $msg['smilies']   = "Sonrisa";
  $msg['refresh']   = "Refrescar";
  $msg['shout']     = "Exclamar!";
  $msg['delete']    = "Cancelar";
  $msg['confirm']   = "Cancelar permanente?";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Entrar contraseña:";
  $msg['wrongPass'] = "Impropio contraseña!";
  $msg['noSpam']    = "NO SPAM, POR FAVOR!";
