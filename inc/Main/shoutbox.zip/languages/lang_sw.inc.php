<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Jina";
  $msg['eMail']     = "Anwanipepe";
  $msg['message']   = "Ujumbe";
  $msg['smilies']   = "Vikaragosi";
  $msg['refresh']   = "Sasisha";
  $msg['shout']     = "Pelekea!";
  $msg['delete']    = "Futa";
  $msg['confirm']   = "Una hakika?";
  $msg['admin']     = "Mwangalizi";
  $msg['pass']      = "Nywila:";
  $msg['wrongPass'] = "Nywila si sahihi!";
  $msg['noSpam']    = "TAFADHALI USIPELEKE BARUATAKA!";
