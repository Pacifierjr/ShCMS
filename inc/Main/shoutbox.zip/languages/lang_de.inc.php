<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Name";
  $msg['eMail']     = "eMail";
  $msg['message']   = "Nachricht";
  $msg['smilies']   = "Smilies";
  $msg['refresh']   = "Neu laden";
  $msg['shout']     = "Shout!";
  $msg['delete']    = "Löschen";
  $msg['confirm']   = "Unwiderruflich löschen?";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Kennwort eingeben:";
  $msg['wrongPass'] = "Falsches Kennwort!";
  $msg['noSpam']    = "NO SPAM PLEASE!";
