<?php
/*********************************************************************************************************
 This code is part of the ShoutBox software (www.gerd-tentler.de/tools/shoutbox), copyright by
 Gerd Tentler. Obtain permission before selling this code or hosting it on a commercial website or
 redistributing it over the Internet or in any other medium. In all cases copyright must remain intact.
*********************************************************************************************************/

  $msg['name']      = "Nomo";
  $msg['eMail']     = "Retadreso";
  $msg['message']   = "Mesa&#285;o";
  $msg['smilies']   = "Miensimboloj";
  $msg['refresh']   = "&#284;isdatigu";
  $msg['shout']     = "Sendu!";
  $msg['delete']    = "Forigu";
  $msg['confirm']   = "Konfirmu?";
  $msg['admin']     = "Admin";
  $msg['pass']      = "Tajpu vian pasvorton:";
  $msg['wrongPass'] = "Nekorekta pasvorto!";
  $msg['noSpam']    = "BONVOLU NE TRUDMESA&#284;I!";
